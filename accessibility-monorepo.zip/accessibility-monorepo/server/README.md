# Server

Recommended foundation:
- REST API boundary
- validation at the edge
- centralized error handling
- environment-based configuration
- structured logging
- no sensitive credentials committed to source
