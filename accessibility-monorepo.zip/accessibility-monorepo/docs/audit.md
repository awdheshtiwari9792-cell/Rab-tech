# Accessibility Baseline & Architecture Audit

## Audited website
**UIDAI — Unique Identification Authority of India**
https://www.uidai.gov.in/en/

Audit date: 24 September 2026

### Evidence reviewed
UIDAI's official Website Help page describes the site's sections, search, sitemap, accessibility statement, screen-reader support, and technical implementation. It states that the site is built using PHP on Joomla and claims WCAG 2.0 Level AA compliance.

### Five findings

| # | Finding | Evidence | Priority | Remediation |
|---|---|---|---|---|
| 1 | Keyboard/focus behavior needs a dedicated regression check | The site states that users can access content with assistive technology, while GIGW requires all functionality to be keyboard operable and the focus indicator to be visible. | P0 | Test every interactive control with Tab/Shift+Tab/Enter/Escape; add a visible `:focus-visible` treatment and automated keyboard regression tests. |
| 2 | Skip-to-content behavior should be explicitly verified | GIGW Quick Tips specifically requires a “Skip to content” link at the top so users can bypass repeated navigation. | P1 | Add/verify a first-focus skip link targeting `<main id="main-content">`. |
| 3 | Image alternative text requires continuous validation | The UIDAI page contains many image-based controls/content, while GIGW requires non-text content to have an appropriate text alternative. | P1 | Audit every meaningful image for useful `alt`; mark decorative images `alt=""`; ensure icon-only buttons have accessible names. |
| 4 | Legacy platform/document dependencies increase maintenance risk | UIDAI's own help page identifies PHP/Joomla and lists external viewers/plugins for PDF, Word, Excel and PowerPoint. | P1 | Isolate document delivery behind a content service, prefer HTML where practical, validate downloadable documents, and avoid unnecessary client-side plugin dependencies. |
| 5 | Navigation complexity requires information-architecture tests | UIDAI documents many top-level sections plus online services, FAQs, resources, media, sitemap and quick links. GIGW recommends multiple ways to locate pages and consistent navigation order. | P1 | Define a small navigation taxonomy, keep repeated navigation stable, provide search/sitemap, and test heading hierarchy and landmark structure. |

## Keyboard-only pass

Use a clean browser session and perform:
1. Load homepage.
2. Press `Tab` repeatedly and confirm the focus indicator is always visible.
3. Confirm the first useful focus target can bypass repeated navigation.
4. Open/close the mobile/menu controls using keyboard only.
5. Operate service cards/links without a mouse.
6. Enter and leave menus/dialogs without focus becoming trapped.
7. Confirm focus order follows the visual/semantic reading order.
8. Check forms and search controls have usable labels.
9. Confirm video/media controls are keyboard operable.
10. Repeat at narrow viewport widths.

## Lighthouse execution

Run a real browser-based Lighthouse audit against:
`https://www.uidai.gov.in/en/`

Example command after installing Lighthouse:

```bash
npx lighthouse https://www.uidai.gov.in/en/ --only-categories=accessibility --output=html --output-path=./docs/lighthouse-accessibility.html
```

Do not copy a score into this report unless the command is actually executed.

## Standards baseline

Use WCAG 2.1/GIGW as the acceptance baseline. GIGW explicitly covers keyboard operation, focus visibility, descriptive headings/labels, multiple navigation mechanisms, and text alternatives.
