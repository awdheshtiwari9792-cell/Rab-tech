# Proposed Full-Stack Architecture

## Monorepo

```text
/
├── client/
│   ├── public/
│   └── src/
├── server/
│   ├── src/
│   └── test/
├── docs/
│   ├── audit.md
│   └── architecture.md
├── test/
├── package.json
└── README.md
```

## Client responsibilities
- pages/routes
- accessible reusable UI
- API calls
- loading/error/empty states
- client-side accessibility checks

## Server responsibilities
- API routes
- request validation
- service layer
- error handling
- security headers and CORS policy
- structured logging

## Quality gates
- unit tests
- API tests
- accessibility tests with axe
- Lighthouse accessibility run in CI
- keyboard regression checklist
- build/type/lint checks

## Suggested future stack
- Client: React + TypeScript + Vite
- Server: Node.js + TypeScript + Fastify/Express
- Tests: Vitest + Playwright
- Accessibility: axe-core + Lighthouse
