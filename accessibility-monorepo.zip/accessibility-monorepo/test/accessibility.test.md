# Accessibility Test Plan

- [ ] Page has one meaningful H1
- [ ] Landmarks are present and named appropriately
- [ ] All interactive elements are keyboard operable
- [ ] Focus is visible
- [ ] Focus order is logical
- [ ] Skip link works
- [ ] Form controls have accessible names
- [ ] Images have appropriate alternative text
- [ ] Buttons/links have descriptive names
- [ ] No keyboard trap
- [ ] Responsive layout works at 320 CSS px
