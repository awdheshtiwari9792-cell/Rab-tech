# Client

Recommended foundation:
- semantic HTML
- keyboard-first interaction
- visible focus states
- responsive layout
- reusable accessible components
- API client isolated from UI components
